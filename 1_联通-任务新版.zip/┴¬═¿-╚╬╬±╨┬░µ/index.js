(async () => {
  require('./AutoSignMachine.js').run()
})()